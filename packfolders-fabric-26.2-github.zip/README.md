# Pack Folders (Fabric / Minecraft 26.2)

リソースパック画面にフォルダー・お気に入り・検索・並べ替えを追加するクライアント専用MODです。

## ビルド
必要: JDK 25 / Gradle 9.3 以上
1. このフォルダーで `gradle wrapper` を実行（または公式テンプレートの gradlew 一式をコピー）
2. `./gradlew build`
3. `build/libs/packfolders-1.0.0.jar` を mods フォルダーへ（Fabric API も必要）

ビルドが通らない場合は https://fabricmc.net/develop/template/ で 26.2 用のプロジェクトを生成し、
この `src/` フォルダーだけを上書きしてください。

## 保存先
`<.minecraft>/config/packfolders.json`
（フォルダー・色・お気に入り・並び順・「お気に入りのみ」の状態）

## コンパイルエラーが出たときの確認箇所（26.2は変更が多いため）
- client/Gfx.java …… 描画APIの呼び出しを全部ここに集約
- 各 Screen の `setScreenAndShow` / `extractRenderState` / `MouseButtonEvent`
- mixin/PackSelectionScreenAccessor.java の `"model"`（バニラ側のフィールド名）
- PackSelectionModel.Entry のメソッド名（getId, select, moveUp など）
名前を確認するには、Loomのキャッシュにあるjarに対して `javap -p` を実行してください。
