package com.example.packfolders.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/**
 * 描画APIの呼び出しをここに集約している。
 * Minecraft のバージョンで描画系のメソッド名が変わったら、このファイルだけ直せばよい。
 * (26.2: GuiGraphics -> GuiGraphicsExtractor, render -> extractRenderState)
 */
final class Gfx {
    private Gfx() {}

    static void fill(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int argb) {
        g.fill(x1, y1, x2, y2, argb);
    }

    static void text(GuiGraphicsExtractor g, Font font, String s, int x, int y, int argb) {
        g.text(font, s, x, y, argb);
    }

    static void centered(GuiGraphicsExtractor g, Font font, String s, int centerX, int y, int argb) {
        g.text(font, s, centerX - font.width(s) / 2, y, argb);
    }

    static void icon(GuiGraphicsExtractor g, Identifier texture, int x, int y, int size) {
        g.blit(RenderPipelines.GUI_TEXTURED, texture, x, y, 0.0F, 0.0F, size, size, size, size);
    }

    /** 幅 maxWidth に収まるように末尾を「…」で省略する */
    static String trim(Font font, String s, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (font.width(s) <= maxWidth) return s;
        int ellipsis = font.width("…");
        return font.plainSubstrByWidth(s, Math.max(0, maxWidth - ellipsis)) + "…";
    }
}
