package com.example.packfolders.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

import java.util.function.BiConsumer;

/** フォルダーの名前と色を決める画面（新規作成・編集の両方で使う） */
public class FolderEditScreen extends Screen {
    private static final int[] PALETTE = {
            0xFF5555, 0xFFAA00, 0xFFFF55, 0x55FF55, 0x00AA00, 0x55FFFF, 0x00AAAA, 0x5555FF,
            0x0000AA, 0xAA00AA, 0xFF55FF, 0xAA0000, 0xFFFFFF, 0xAAAAAA, 0x555555, 0x8B5A2B
    };
    private static final int CELL = 20;
    private static final int GAP = 2;
    private static final int COLS = 8;

    private final Screen parent;
    private final BiConsumer<String, Integer> onSave;
    private final String initialName;
    private int color;

    private EditBox nameBox;
    private EditBox hexBox;
    private int gridX;
    private int gridY;
    private int top;

    /** name が null なら新規作成 */
    public FolderEditScreen(Screen parent, String name, int color, BiConsumer<String, Integer> onSave) {
        super(Component.translatable(name == null ? "packfolders.create_title" : "packfolders.edit_title"));
        this.parent = parent;
        this.initialName = name == null ? "" : name;
        this.color = color & 0xFFFFFF;
        this.onSave = onSave;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        this.top = Math.max(12, this.height / 2 - 100);

        String keepName = this.nameBox != null ? this.nameBox.getValue() : this.initialName;

        this.nameBox = new EditBox(this.font, cx - 90, top + 30, 180, 20,
                Component.translatable("packfolders.folder_name"));
        this.nameBox.setMaxLength(32);
        this.nameBox.setValue(keepName);
        this.addRenderableWidget(this.nameBox);
        this.setInitialFocus(this.nameBox);

        this.gridX = cx - (COLS * (CELL + GAP) - GAP) / 2;
        this.gridY = top + 72;

        this.hexBox = new EditBox(this.font, cx - 90, top + 133, 80, 20,
                Component.translatable("packfolders.color_code"));
        this.hexBox.setMaxLength(7);
        this.hexBox.setValue(formatColor(this.color));
        this.hexBox.setResponder(this::onHexChanged);
        this.addRenderableWidget(this.hexBox);

        this.addRenderableWidget(Button.builder(CommonComponents.GUI_OK, b -> save())
                .bounds(cx - 90, top + 165, 88, 20).build());
        this.addRenderableWidget(Button.builder(CommonComponents.GUI_CANCEL, b -> onClose())
                .bounds(cx + 2, top + 165, 88, 20).build());
    }

    private static String formatColor(int rgb) {
        return String.format("#%06X", rgb & 0xFFFFFF);
    }

    private void onHexChanged(String text) {
        String s = text.trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (s.length() != 6) return;
        try {
            this.color = Integer.parseInt(s, 16) & 0xFFFFFF;
        } catch (NumberFormatException ignored) {
            // 入力途中は無視
        }
    }

    private void setColor(int rgb) {
        this.color = rgb & 0xFFFFFF;
        this.hexBox.setValue(formatColor(this.color));
    }

    private void save() {
        String name = this.nameBox.getValue().trim();
        if (name.isEmpty()) {
            name = Component.translatable("packfolders.default_folder_name").getString();
        }
        this.onSave.accept(name, this.color & 0xFFFFFF);
        this.minecraft.setScreenAndShow(this.parent);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(this.parent);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) {
            return true;
        }
        if (event.button() == 0) {
            for (int i = 0; i < PALETTE.length; i++) {
                int x = gridX + (i % COLS) * (CELL + GAP);
                int y = gridY + (i / COLS) * (CELL + GAP);
                if (event.x() >= x && event.x() < x + CELL && event.y() >= y && event.y() < y + CELL) {
                    setColor(PALETTE[i]);
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);
        int cx = this.width / 2;

        Gfx.centered(g, this.font, this.title.getString(), cx, top, 0xFFFFFFFF);
        Gfx.text(g, this.font, Component.translatable("packfolders.folder_name").getString(),
                cx - 90, top + 18, 0xFFAAAAAA);
        Gfx.text(g, this.font, Component.translatable("packfolders.folder_color").getString(),
                gridX, top + 60, 0xFFAAAAAA);
        Gfx.text(g, this.font, Component.translatable("packfolders.color_code").getString(),
                cx - 90, top + 122, 0xFFAAAAAA);

        // パレット
        for (int i = 0; i < PALETTE.length; i++) {
            int x = gridX + (i % COLS) * (CELL + GAP);
            int y = gridY + (i / COLS) * (CELL + GAP);
            boolean selected = PALETTE[i] == this.color;
            Gfx.fill(g, x - 1, y - 1, x + CELL + 1, y + CELL + 1, selected ? 0xFFFFFFFF : 0xFF000000);
            Gfx.fill(g, x, y, x + CELL, y + CELL, 0xFF000000 | PALETTE[i]);
        }

        // プレビュー
        int px = cx - 90 + 88;
        int py = top + 133;
        Gfx.fill(g, px - 1, py - 1, px + 21, py + 21, 0xFFFFFFFF);
        Gfx.fill(g, px, py, px + 20, py + 20, 0xFF000000 | this.color);
    }
}
