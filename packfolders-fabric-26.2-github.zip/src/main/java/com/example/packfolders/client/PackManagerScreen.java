package com.example.packfolders.client;

import com.example.packfolders.data.PackFolderStore;
import com.example.packfolders.data.PackFolderStore.Folder;
import com.example.packfolders.mixin.PackSelectionScreenAccessor;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.packs.PackSelectionModel;
import net.minecraft.client.gui.screens.packs.PackSelectionScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * バニラのリソースパック画面の代わりに表示する画面。
 * パックの選択状態・適用処理はバニラの PackSelectionModel / PackSelectionScreen にそのまま任せ、
 * 左一覧の「見せ方と並び順」だけをこのMODが管理する。
 */
public class PackManagerScreen extends Screen {
    // ---- バニラ画面を二重に差し替えないための目印 ----
    private static final Set<Screen> WRAPPED = Collections.newSetFromMap(new WeakHashMap<>());

    public static void markWrapped(Screen s) {
        WRAPPED.add(s);
    }

    public static boolean isWrapped(Screen s) {
        return WRAPPED.contains(s);
    }

    // ---- レイアウト定数 ----
    private static final int PACK_H = 36;
    private static final int FOLDER_H = 26;
    private static final int SCROLL_W = 6;
    private static final int INDENT = 12;

    private enum Zone { NONE, BODY, ICON, UP, DOWN, STAR, MOVE, EDIT, DELETE }

    /** 一覧の1行（フォルダー見出し or リソースパック） */
    private static final class Row {
        final boolean folderRow;
        final PackSelectionModel.Entry entry; // パック行のみ
        final Folder folder;                  // フォルダー行のみ
        final Folder parent;                  // フォルダー内のパック行のみ
        final int count;                      // フォルダー内のパック数
        boolean canUp;
        boolean canDown;
        // 直近の描画位置（クリック判定に使う）
        int x, y, w, h;
        boolean visible;

        private Row(boolean folderRow, PackSelectionModel.Entry entry, Folder folder, Folder parent, int count) {
            this.folderRow = folderRow;
            this.entry = entry;
            this.folder = folder;
            this.parent = parent;
            this.count = count;
        }

        static Row folder(Folder f, int count) {
            return new Row(true, null, f, null, count);
        }

        static Row pack(PackSelectionModel.Entry e, Folder parent) {
            return new Row(false, e, null, parent, 0);
        }

        int height() {
            return folderRow ? FOLDER_H : PACK_H;
        }
    }

    private final PackSelectionScreen vanilla;
    private final PackSelectionModel model;
    private final PackFolderStore store = PackFolderStore.get();

    private final List<Row> leftRows = new ArrayList<>();
    private final List<Row> rightRows = new ArrayList<>();
    /** 今の絞り込みで表示されているトークン（"F:id" / "P:id"）。並べ替え時に隠れた項目を飛ばすために使う */
    private final Set<String> visibleTokens = new HashSet<>();

    private EditBox searchBox;
    private Button favButton;

    private int panelW;
    private int leftX;
    private int rightX;
    private int listTop;
    private int listBottom;

    private int leftFirst;
    private int rightFirst;
    private String lastSignature = "";

    public PackManagerScreen(PackSelectionScreen vanilla) {
        super(vanilla.getTitle());
        this.vanilla = vanilla;
        this.model = ((PackSelectionScreenAccessor) vanilla).packfolders$getModel();
    }

    // ================================================================== 初期化

    @Override
    protected void init() {
        // バニラ画面側も初期化しておく（選択変更の通知や、完了時の適用処理がこの画面を前提にしているため）
        this.vanilla.init(this.minecraft, this.width, this.height);

        this.panelW = Math.min(220, (this.width - 24) / 2);
        this.leftX = this.width / 2 - 4 - panelW;
        this.rightX = this.width / 2 + 4;
        this.listTop = 46;
        this.listBottom = this.height - 62;

        // 一覧の上：お気に入り絞り込み / フォルダー作成
        int bw = (panelW - 4) / 2;
        this.favButton = this.addRenderableWidget(Button.builder(favLabel(), b -> {
            store.favoritesOnly = !store.favoritesOnly;
            store.save();
            b.setMessage(favLabel());
            leftFirst = 0;
            rebuild();
        }).bounds(leftX, 22, bw, 20).build());

        this.addRenderableWidget(Button.builder(Component.translatable("packfolders.new_folder"),
                b -> openFolderEditor(null)).bounds(leftX + bw + 4, 22, bw, 20).build());

        // 一覧の左下：検索ボックス
        String oldSearch = this.searchBox == null ? "" : this.searchBox.getValue();
        this.searchBox = new EditBox(this.font, leftX, this.height - 56, panelW, 20,
                Component.translatable("packfolders.search"));
        this.searchBox.setHint(Component.translatable("packfolders.search_hint"));
        this.searchBox.setMaxLength(64);
        this.searchBox.setValue(oldSearch);
        this.searchBox.setResponder(s -> {
            leftFirst = 0;
            rebuild();
        });
        this.addRenderableWidget(this.searchBox);

        // 下部ボタン
        this.addRenderableWidget(Button.builder(Component.translatable("packfolders.open_folder"),
                        b -> Util.getPlatform().openPath(this.minecraft.getResourcePackDirectory()))
                .bounds(this.width / 2 - 154, this.height - 28, 150, 20).build());
        this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
                .bounds(this.width / 2 + 4, this.height - 28, 150, 20).build());

        rebuild();
    }

    private Component favLabel() {
        Component base = Component.translatable(store.favoritesOnly
                ? "packfolders.fav_only_on" : "packfolders.fav_only_off");
        return store.favoritesOnly ? base.copy().withStyle(ChatFormatting.YELLOW) : base;
    }

    // ================================================================== 一覧の組み立て

    private boolean matches(PackSelectionModel.Entry e, String query) {
        if (store.favoritesOnly && !store.isFavorite(e.getId())) {
            return false;
        }
        if (!query.isEmpty()) {
            String title = clean(e.getTitle().getString()).toLowerCase(Locale.ROOT);
            String id = e.getId().toLowerCase(Locale.ROOT);
            return title.contains(query) || id.contains(query);
        }
        return true;
    }

    private void rebuild() {
        leftRows.clear();
        rightRows.clear();
        visibleTokens.clear();

        // 左：未選択のパック
        Map<String, PackSelectionModel.Entry> avail = new LinkedHashMap<>();
        model.getUnselected().forEach(e -> avail.put(e.getId(), e));

        // 右：選択中のパック（バニラの並び＝適用の優先順位そのまま）
        List<String> allIds = new ArrayList<>(avail.keySet());
        model.getSelected().forEach(e -> {
            allIds.add(e.getId());
            Row r = Row.pack(e, null);
            r.canUp = e.canMoveUp();
            r.canDown = e.canMoveDown();
            rightRows.add(r);
        });

        // 初めて見るパックを並び順リストに登録
        store.sync(allIds);

        String query = this.searchBox == null ? "" : this.searchBox.getValue().trim().toLowerCase(Locale.ROOT);
        boolean searching = !query.isEmpty();
        boolean filtering = searching || store.favoritesOnly;

        for (String token : new ArrayList<>(store.rootOrder)) {
            if (token.startsWith("F:")) {
                Folder f = store.findFolder(token.substring(2));
                if (f == null) continue;

                List<Row> children = new ArrayList<>();
                int total = 0;
                for (String packId : f.packs) {
                    PackSelectionModel.Entry e = avail.get(packId);
                    if (e == null) continue;
                    total++;
                    if (matches(e, query)) {
                        children.add(Row.pack(e, f));
                    }
                }
                if (filtering && children.isEmpty()) continue; // 絞り込み中は空のフォルダーを隠す

                leftRows.add(Row.folder(f, total));
                visibleTokens.add(token);

                boolean expanded = !f.collapsed || searching; // 検索中は閉じていても中身を出す
                if (expanded) {
                    for (Row c : children) {
                        leftRows.add(c);
                        visibleTokens.add("P:" + c.entry.getId());
                    }
                }
            } else if (token.startsWith("P:")) {
                String packId = token.substring(2);
                if (store.folderOf(packId) != null) continue;
                PackSelectionModel.Entry e = avail.get(packId);
                if (e == null || !matches(e, query)) continue;
                leftRows.add(Row.pack(e, null));
                visibleTokens.add(token);
            }
        }

        computeMoveFlags();

        leftFirst = Math.max(0, Math.min(leftFirst, maxFirst(leftRows)));
        rightFirst = Math.max(0, Math.min(rightFirst, maxFirst(rightRows)));
        lastSignature = signature();
    }

    /** 各行の ▲▼ が有効かを決める（同じ階層で、前後に表示中の項目があるか） */
    private void computeMoveFlags() {
        List<Row> roots = new ArrayList<>();
        Map<Folder, List<Row>> children = new HashMap<>();
        for (Row r : leftRows) {
            if (r.parent == null) {
                roots.add(r);
            } else {
                children.computeIfAbsent(r.parent, k -> new ArrayList<>()).add(r);
            }
        }
        for (int i = 0; i < roots.size(); i++) {
            roots.get(i).canUp = i > 0;
            roots.get(i).canDown = i < roots.size() - 1;
        }
        for (List<Row> list : children.values()) {
            for (int i = 0; i < list.size(); i++) {
                list.get(i).canUp = i > 0;
                list.get(i).canDown = i < list.size() - 1;
            }
        }
    }

    private String signature() {
        StringBuilder sb = new StringBuilder();
        model.getUnselected().forEach(e -> sb.append(e.getId()).append('|'));
        sb.append('#');
        model.getSelected().forEach(e -> sb.append(e.getId()).append('|'));
        return sb.toString();
    }

    /** 全部の行が収まる最小の先頭インデックス（これより大きくスクロールさせない） */
    private int maxFirst(List<Row> rows) {
        int viewH = listBottom - listTop - 4;
        int sum = 0;
        int i = rows.size();
        while (i > 0 && sum + rows.get(i - 1).height() <= viewH) {
            sum += rows.get(i - 1).height();
            i--;
        }
        return i;
    }

    private static String clean(String s) {
        String stripped = ChatFormatting.stripFormatting(s);
        return (stripped == null ? "" : stripped).replace('\n', ' ');
    }

    // ================================================================== 描画

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);

        Gfx.centered(g, this.font, this.title.getString(), this.width / 2, 8, 0xFFFFFFFF);
        Gfx.text(g, this.font, Component.translatable("packfolders.selected").getString(),
                rightX, 30, 0xFFFFFFFF);

        drawPanel(g, leftRows, leftFirst, leftX, true, mouseX, mouseY);
        drawPanel(g, rightRows, rightFirst, rightX, false, mouseX, mouseY);
    }

    private void drawPanel(GuiGraphicsExtractor g, List<Row> rows, int first, int px,
                           boolean left, int mouseX, int mouseY) {
        Gfx.fill(g, px - 1, listTop - 1, px + panelW + 1, listBottom + 1, 0xFF000000);
        Gfx.fill(g, px, listTop, px + panelW, listBottom, 0xC0101010);

        for (Row r : rows) r.visible = false;

        if (rows.isEmpty()) {
            String msg = Gfx.trim(this.font, Component.translatable("packfolders.empty").getString(), panelW - 8);
            Gfx.centered(g, this.font, msg, px + panelW / 2, (listTop + listBottom) / 2 - 4, 0xFF888888);
            return;
        }

        int rowX = px + 2;
        int rowW = panelW - 4 - SCROLL_W;
        int y = listTop + 2;
        for (int i = first; i < rows.size(); i++) {
            Row r = rows.get(i);
            int h = r.height();
            if (y + h > listBottom - 2) break; // 途中で切れる行は描かない
            r.x = rowX;
            r.y = y;
            r.w = rowW;
            r.h = h;
            r.visible = true;
            if (r.folderRow) {
                drawFolderRow(g, r, mouseX, mouseY);
            } else {
                drawPackRow(g, r, left, mouseX, mouseY);
            }
            y += h;
        }

        drawScrollbar(g, rows, first, px);
    }

    private void drawScrollbar(GuiGraphicsExtractor g, List<Row> rows, int first, int px) {
        int maxF = maxFirst(rows);
        if (maxF <= 0) return;
        int trackX = px + panelW - SCROLL_W;
        int trackTop = listTop + 2;
        int trackH = listBottom - listTop - 4;
        int shown = Math.max(1, rows.size() - maxF);
        int thumbH = Math.max(14, trackH * shown / rows.size());
        int thumbY = trackTop + (trackH - thumbH) * first / maxF;
        Gfx.fill(g, trackX, trackTop, trackX + SCROLL_W - 2, trackTop + trackH, 0xFF000000);
        Gfx.fill(g, trackX, thumbY, trackX + SCROLL_W - 2, thumbY + thumbH, 0xFF8B8B8B);
    }

    private boolean isHover(Row r, int mx, int my) {
        return mx >= r.x && mx < r.x + r.w && my >= r.y && my < r.y + r.h;
    }

    private void glyphButton(GuiGraphicsExtractor g, int x, int y, String glyph,
                             boolean enabled, boolean hover, int color) {
        int bg = !enabled ? 0x80202020 : hover ? 0xFF606060 : 0xB0000000;
        Gfx.fill(g, x, y, x + 12, y + 12, bg);
        Gfx.centered(g, this.font, glyph, x + 6, y + 2, enabled ? color : 0xFF555555);
    }

    private void drawFolderRow(GuiGraphicsExtractor g, Row r, int mx, int my) {
        Folder f = r.folder;
        boolean hover = isHover(r, mx, my);
        int rgb = f.color & 0xFFFFFF;

        Gfx.fill(g, r.x, r.y, r.x + r.w, r.y + r.h, ((hover ? 0x70 : 0x45) << 24) | rgb);
        Gfx.fill(g, r.x, r.y, r.x + 4, r.y + r.h, 0xFF000000 | rgb);

        Gfx.text(g, this.font, f.collapsed ? "▶" : "▼", r.x + 8, r.y + 9, 0xFFFFFFFF);

        int textX = r.x + 20;
        if (hover) {
            Zone z = zoneAt(r, true, mx, my);
            int bx = r.x + r.w - 14;
            int by = r.y + 7;
            glyphButton(g, bx, by, "×", true, z == Zone.DELETE, 0xFFFF7777);
            glyphButton(g, bx - 14, by, "✎", true, z == Zone.EDIT, 0xFFFFFFFF);
            glyphButton(g, bx - 28, by, "▼", r.canDown, z == Zone.DOWN, 0xFFFFFFFF);
            glyphButton(g, bx - 42, by, "▲", r.canUp, z == Zone.UP, 0xFFFFFFFF);
            Gfx.text(g, this.font, Gfx.trim(this.font, f.name, r.w - 20 - 48), textX, r.y + 9, 0xFFFFFFFF);
        } else {
            String count = "(" + r.count + ")";
            int cw = this.font.width(count);
            Gfx.text(g, this.font, count, r.x + r.w - 4 - cw, r.y + 9, 0xFFBBBBBB);
            Gfx.text(g, this.font, Gfx.trim(this.font, f.name, r.w - 20 - cw - 10), textX, r.y + 9, 0xFFFFFFFF);
        }
    }

    private void drawPackRow(GuiGraphicsExtractor g, Row r, boolean left, int mx, int my) {
        PackSelectionModel.Entry e = r.entry;
        boolean hover = isHover(r, mx, my);
        int indent = r.parent != null ? INDENT : 0;
        boolean fav = left && store.isFavorite(e.getId());

        if (hover) {
            Gfx.fill(g, r.x, r.y, r.x + r.w, r.y + r.h, 0x30FFFFFF);
        }
        if (r.parent != null) {
            Gfx.fill(g, r.x + 2, r.y, r.x + 5, r.y + r.h, 0xFF000000 | (r.parent.color & 0xFFFFFF));
        }

        int ix = r.x + 4 + indent;
        int iy = r.y + 2;
        Gfx.icon(g, e.getIconTexture(), ix, iy, 32);

        Zone z = hover ? zoneAt(r, left, mx, my) : Zone.NONE;
        if (z == Zone.ICON) {
            Gfx.fill(g, ix, iy, ix + 32, iy + 32, 0x60FFFFFF);
            Gfx.centered(g, this.font, left ? "▶" : "◀", ix + 16, iy + 12, 0xFFFFFFFF);
        }

        int textX = ix + 32 + 4;
        int reserved = hover ? (left ? 34 : 18) : (fav ? 18 : 4);
        int textW = r.x + r.w - textX - reserved;
        String title = clean(e.getTitle().getString());
        String desc = clean(e.getDescription().getString());
        Gfx.text(g, this.font, Gfx.trim(this.font, title, textW), textX, r.y + 4, 0xFFFFFFFF);
        Gfx.text(g, this.font, Gfx.trim(this.font, desc, textW), textX, r.y + 16, 0xFFAAAAAA);

        if (hover) {
            int bx2 = r.x + r.w - 14;
            glyphButton(g, bx2, r.y + 3, "▲", r.canUp, z == Zone.UP, 0xFFFFFFFF);
            glyphButton(g, bx2, r.y + 21, "▼", r.canDown, z == Zone.DOWN, 0xFFFFFFFF);
            if (left) {
                int bx1 = r.x + r.w - 28;
                glyphButton(g, bx1, r.y + 3, fav ? "★" : "☆", true, z == Zone.STAR, fav ? 0xFFFFD700 : 0xFFFFFFFF);
                glyphButton(g, bx1, r.y + 21, "▤", true, z == Zone.MOVE, 0xFFFFFFFF);
            }
        } else if (fav) {
            Gfx.text(g, this.font, "★", r.x + r.w - 12, r.y + 4, 0xFFFFD700);
        }
    }

    // ================================================================== 入力

    /** 行のどの部分にマウスがあるか */
    private Zone zoneAt(Row r, boolean left, double mx, double my) {
        if (!r.visible || mx < r.x || mx >= r.x + r.w || my < r.y || my >= r.y + r.h) {
            return Zone.NONE;
        }
        if (r.folderRow) {
            int bx = r.x + r.w - 14;
            if (my >= r.y + 7 && my < r.y + 19) {
                if (mx >= bx && mx < bx + 12) return Zone.DELETE;
                if (mx >= bx - 14 && mx < bx - 2) return Zone.EDIT;
                if (mx >= bx - 28 && mx < bx - 16) return Zone.DOWN;
                if (mx >= bx - 42 && mx < bx - 30) return Zone.UP;
            }
            return Zone.BODY;
        }
        int bx2 = r.x + r.w - 14;
        int bx1 = r.x + r.w - 28;
        if (mx >= bx2 && mx < bx2 + 12) {
            if (my >= r.y + 3 && my < r.y + 15) return Zone.UP;
            if (my >= r.y + 21 && my < r.y + 33) return Zone.DOWN;
        }
        if (left && mx >= bx1 && mx < bx1 + 12) {
            if (my >= r.y + 3 && my < r.y + 15) return Zone.STAR;
            if (my >= r.y + 21 && my < r.y + 33) return Zone.MOVE;
        }
        int indent = r.parent != null ? INDENT : 0;
        int ix = r.x + 4 + indent;
        if (mx >= ix && mx < ix + 32 && my >= r.y + 2 && my < r.y + 34) {
            return Zone.ICON;
        }
        return Zone.BODY;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) {
            return true;
        }
        int button = event.button();
        if (button != 0 && button != 1) {
            return false;
        }
        double mx = event.x();
        double my = event.y();
        for (int side = 0; side < 2; side++) {
            boolean left = side == 0;
            for (Row r : left ? leftRows : rightRows) {
                Zone z = zoneAt(r, left, mx, my);
                if (z == Zone.NONE) continue;
                act(r, left, z, button, doubleClick);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (my >= listTop && my < listBottom) {
            int d = scrollY > 0 ? -1 : 1;
            if (mx >= leftX && mx < leftX + panelW) {
                leftFirst = Math.max(0, Math.min(leftFirst + d, maxFirst(leftRows)));
                return true;
            }
            if (mx >= rightX && mx < rightX + panelW) {
                rightFirst = Math.max(0, Math.min(rightFirst + d, maxFirst(rightRows)));
                return true;
            }
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    private void act(Row r, boolean left, Zone z, int button, boolean doubleClick) {
        if (r.folderRow) {
            Folder f = r.folder;
            switch (z) {
                case UP -> store.moveToken(store.rootOrder, "F:" + f.id, -1, visibleTokens::contains);
                case DOWN -> store.moveToken(store.rootOrder, "F:" + f.id, 1, visibleTokens::contains);
                case EDIT -> openFolderEditor(f);
                case DELETE -> confirmDelete(f);
                default -> {
                    if (button == 1) {
                        openFolderEditor(f);
                    } else {
                        f.collapsed = !f.collapsed; // 折りたたみ／展開
                    }
                }
            }
        } else if (left) {
            PackSelectionModel.Entry e = r.entry;
            String id = e.getId();
            switch (z) {
                case UP, DOWN -> {
                    int dir = z == Zone.UP ? -1 : 1;
                    if (r.parent != null) {
                        store.moveToken(r.parent.packs, id, dir, t -> visibleTokens.contains("P:" + t));
                    } else {
                        store.moveToken(store.rootOrder, "P:" + id, dir, visibleTokens::contains);
                    }
                }
                case STAR -> store.toggleFavorite(id);
                case MOVE -> openChooser(r);
                case ICON -> selectEntry(e);
                default -> {
                    if (button == 1) {
                        openChooser(r);
                    } else if (doubleClick) {
                        selectEntry(e);
                    }
                }
            }
        } else {
            PackSelectionModel.Entry e = r.entry;
            switch (z) {
                case UP -> {
                    if (e.canMoveUp()) e.moveUp();
                }
                case DOWN -> {
                    if (e.canMoveDown()) e.moveDown();
                }
                case ICON -> unselectEntry(e);
                default -> {
                    if (doubleClick) unselectEntry(e);
                }
            }
        }
        store.save();
        rebuild();
    }

    private void selectEntry(PackSelectionModel.Entry e) {
        if (!e.canSelect()) return;
        if (!e.getCompatibility().isCompatible()) {
            this.minecraft.setScreenAndShow(new ConfirmScreen(yes -> {
                this.minecraft.setScreenAndShow(this);
                if (yes) {
                    e.select();
                    rebuild();
                }
            }, Component.translatable("packfolders.incompatible_title"),
                    Component.translatable("packfolders.incompatible_message")));
            return;
        }
        e.select();
    }

    private void unselectEntry(PackSelectionModel.Entry e) {
        if (e.canUnselect()) {
            e.unselect();
        }
    }

    // ================================================================== フォルダー操作の画面遷移

    private void openFolderEditor(Folder existing) {
        String name = existing == null ? null : existing.name;
        int color = existing == null ? 0x55AAFF : existing.color;
        this.minecraft.setScreenAndShow(new FolderEditScreen(this, name, color, (newName, newColor) -> {
            if (existing == null) {
                store.createFolder(newName, newColor);
            } else {
                existing.name = newName;
                existing.color = newColor;
            }
            store.save();
            rebuild();
        }));
    }

    private void confirmDelete(Folder f) {
        this.minecraft.setScreenAndShow(new ConfirmScreen(yes -> {
            if (yes) {
                store.deleteFolder(f);
                store.save();
            }
            this.minecraft.setScreenAndShow(this);
        }, Component.translatable("packfolders.delete_title"),
                Component.translatable("packfolders.delete_message", f.name)));
    }

    private void openChooser(Row r) {
        String packId = r.entry.getId();
        Folder current = store.folderOf(packId);
        this.minecraft.setScreenAndShow(new FolderChooseScreen(
                this,
                clean(r.entry.getTitle().getString()),
                new ArrayList<>(store.folders),
                current == null ? null : current.id,
                target -> {
                    store.movePackToFolder(packId, target);
                    store.save();
                    rebuild();
                }));
    }

    // ================================================================== ライフサイクル

    @Override
    public void tick() {
        // フォルダー監視（外部からパックが追加された時の検知）をバニラ側に任せる
        this.vanilla.tick();
        if (!signature().equals(lastSignature)) {
            rebuild();
        }
    }

    @Override
    public void onClose() {
        store.save();
        // 選択の確定・リソースの再読み込み・元の画面に戻る処理はバニラの実装に任せる
        this.vanilla.onClose();
    }

    @Override
    public void removed() {
        store.save();
        super.removed();
    }
}
