package com.example.packfolders.client;

import com.example.packfolders.data.PackFolderStore.Folder;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.function.Consumer;

/** リソースパックの移動先フォルダーを選ぶ画面。「フォルダーなし」を選ぶと null が渡される。 */
public class FolderChooseScreen extends Screen {
    private static final int PER_PAGE = 6;

    private final Screen parent;
    private final String packName;
    private final List<Folder> folders;
    private final String currentFolderId;
    private final Consumer<Folder> onChoose;
    private int page;

    public FolderChooseScreen(Screen parent, String packName, List<Folder> folders,
                              String currentFolderId, Consumer<Folder> onChoose) {
        super(Component.translatable("packfolders.choose_title"));
        this.parent = parent;
        this.packName = packName;
        this.folders = folders;
        this.currentFolderId = currentFolderId;
        this.onChoose = onChoose;
    }

    private int pageCount() {
        int total = folders.size() + 1; // 先頭は「フォルダーなし」
        return Math.max(1, (total + PER_PAGE - 1) / PER_PAGE);
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y0 = 44;
        int total = folders.size() + 1;
        int pages = pageCount();
        this.page = Math.min(this.page, pages - 1);

        for (int k = 0; k < PER_PAGE; k++) {
            int idx = page * PER_PAGE + k;
            if (idx >= total) break;

            final Folder f = idx == 0 ? null : folders.get(idx - 1);
            boolean current = f == null ? currentFolderId == null : f.id.equals(currentFolderId);

            Component label;
            if (f == null) {
                label = Component.translatable("packfolders.no_folder");
            } else {
                final int rgb = f.color;
                label = Component.literal(f.name).withStyle(s -> s.withColor(rgb));
            }

            Button b = Button.builder(label, btn -> {
                this.onChoose.accept(f);
                this.minecraft.setScreenAndShow(this.parent);
            }).bounds(cx - 100, y0 + k * 24, 200, 20).build();
            b.active = !current; // 今いる場所は選べない
            this.addRenderableWidget(b);
        }

        if (pages > 1) {
            int y = y0 + PER_PAGE * 24 + 4;
            Button prev = Button.builder(Component.literal("◀"), b -> {
                this.page--;
                this.rebuildWidgets();
            }).bounds(cx - 100, y, 30, 20).build();
            prev.active = page > 0;
            this.addRenderableWidget(prev);

            Button next = Button.builder(Component.literal("▶"), b -> {
                this.page++;
                this.rebuildWidgets();
            }).bounds(cx + 70, y, 30, 20).build();
            next.active = page < pages - 1;
            this.addRenderableWidget(next);
        }

        this.addRenderableWidget(Button.builder(CommonComponents.GUI_CANCEL, b -> onClose())
                .bounds(cx - 100, this.height - 28, 200, 20).build());
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(this.parent);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);
        int cx = this.width / 2;
        Gfx.centered(g, this.font, this.title.getString(), cx, 12, 0xFFFFFFFF);
        Gfx.centered(g, this.font, Gfx.trim(this.font, packName, 260), cx, 27, 0xFFAAAAAA);

        int pages = pageCount();
        if (pages > 1) {
            String label = (page + 1) + " / " + pages;
            Gfx.centered(g, this.font, label, cx, 44 + PER_PAGE * 24 + 10, 0xFFFFFFFF);
        }
    }
}
