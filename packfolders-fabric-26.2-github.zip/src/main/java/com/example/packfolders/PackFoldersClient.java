package com.example.packfolders;

import com.example.packfolders.client.PackManagerScreen;
import com.example.packfolders.data.PackFolderStore;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screens.packs.PackSelectionScreen;
import net.minecraft.network.chat.contents.TranslatableContents;

public class PackFoldersClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // 起動時にデータを読み込む（ファイルが無ければ空で開始）
        PackFolderStore.get();

        ScreenEvents.BEFORE_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof PackSelectionScreen vanilla
                    && !PackManagerScreen.isWrapped(vanilla)
                    && isResourcePackScreen(vanilla)) {
                // 同じ画面を二重に差し替えないよう印を付け、次のタスクで自作画面に置き換える
                PackManagerScreen.markWrapped(vanilla);
                client.execute(() -> client.setScreenAndShow(new PackManagerScreen(vanilla)));
            }
        });
    }

    /** データパック選択画面ではなく、リソースパック選択画面だけを対象にする */
    private static boolean isResourcePackScreen(PackSelectionScreen screen) {
        return screen.getTitle().getContents() instanceof TranslatableContents tc
                && "resourcePack.title".equals(tc.getKey());
    }
}
