package com.example.packfolders.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

/**
 * フォルダー・お気に入り・並び順を保存するデータ。
 * config/packfolders.json に保存されるので、ログアウトやゲーム終了後も残る。
 *
 * rootOrder のトークン形式:
 *   "F:<folderId>" = フォルダー
 *   "P:<packId>"   = フォルダーに入っていないリソースパック
 */
public final class PackFolderStore {
    private static final Logger LOGGER = LoggerFactory.getLogger("packfolders");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static PackFolderStore instance;

    public static final class Folder {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public int color = 0x55AAFF;
        public boolean collapsed = false;
        /** フォルダー内のパックID（表示順） */
        public List<String> packs = new ArrayList<>();
    }

    public int version = 1;
    public boolean favoritesOnly = false;
    public List<Folder> folders = new ArrayList<>();
    public List<String> favorites = new ArrayList<>();
    public List<String> rootOrder = new ArrayList<>();

    // ---------------------------------------------------------------- 読み書き

    public static synchronized PackFolderStore get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("packfolders.json");
    }

    private static PackFolderStore load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                PackFolderStore s = GSON.fromJson(r, PackFolderStore.class);
                if (s != null) {
                    s.normalize();
                    return s;
                }
            } catch (Exception e) {
                LOGGER.error("Failed to read packfolders.json. A backup is kept as packfolders.json.broken", e);
                try {
                    Files.copy(p, p.resolveSibling("packfolders.json.broken"), StandardCopyOption.REPLACE_EXISTING);
                } catch (IOException ignored) {
                    // ignore
                }
            }
        }
        return new PackFolderStore();
    }

    public synchronized void save() {
        Path p = path();
        Path tmp = p.resolveSibling("packfolders.json.tmp");
        try {
            Files.createDirectories(p.getParent());
            Files.writeString(tmp, GSON.toJson(this), StandardCharsets.UTF_8);
            try {
                Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            LOGGER.error("Failed to save packfolders.json", e);
        }
    }

    /** 読み込み直後にデータの矛盾を直す */
    private void normalize() {
        if (folders == null) folders = new ArrayList<>();
        if (favorites == null) favorites = new ArrayList<>();
        if (rootOrder == null) rootOrder = new ArrayList<>();

        folders.removeIf(f -> f == null);
        Set<String> seenFolderIds = new HashSet<>();
        Set<String> seenPacks = new HashSet<>();
        for (Folder f : folders) {
            if (f.id == null || f.id.isBlank() || !seenFolderIds.add(f.id)) {
                f.id = UUID.randomUUID().toString();
                seenFolderIds.add(f.id);
            }
            if (f.name == null) f.name = "";
            if (f.packs == null) f.packs = new ArrayList<>();
            f.packs.removeIf(id -> id == null || !seenPacks.add(id));
            f.color &= 0xFFFFFF;
        }

        Set<String> favSeen = new HashSet<>();
        favorites.removeIf(id -> id == null || !favSeen.add(id));

        Set<String> tokenSeen = new HashSet<>();
        rootOrder.removeIf(t -> {
            if (t == null || !tokenSeen.add(t)) return true;
            if (t.startsWith("F:")) return findFolder(t.substring(2)) == null;
            if (t.startsWith("P:")) return seenPacks.contains(t.substring(2));
            return true;
        });
        for (Folder f : folders) {
            if (!tokenSeen.contains("F:" + f.id)) {
                rootOrder.add("F:" + f.id);
            }
        }
    }

    // ---------------------------------------------------------------- 検索

    public Folder findFolder(String id) {
        for (Folder f : folders) {
            if (f.id.equals(id)) return f;
        }
        return null;
    }

    public Folder folderOf(String packId) {
        for (Folder f : folders) {
            if (f.packs.contains(packId)) return f;
        }
        return null;
    }

    // ---------------------------------------------------------------- お気に入り

    public boolean isFavorite(String packId) {
        return favorites.contains(packId);
    }

    public void toggleFavorite(String packId) {
        if (!favorites.remove(packId)) {
            favorites.add(packId);
        }
    }

    // ---------------------------------------------------------------- フォルダー操作

    public Folder createFolder(String name, int color) {
        Folder f = new Folder();
        f.name = name;
        f.color = color & 0xFFFFFF;
        folders.add(f);
        rootOrder.add("F:" + f.id);
        return f;
    }

    public void deleteFolder(Folder f) {
        int idx = rootOrder.indexOf("F:" + f.id);
        rootOrder.remove("F:" + f.id);
        int at = idx < 0 ? rootOrder.size() : idx;
        for (String packId : f.packs) {
            rootOrder.add(Math.min(at, rootOrder.size()), "P:" + packId);
            at++;
        }
        folders.remove(f);
    }

    /** target が null ならフォルダーの外（ルート）へ */
    public void movePackToFolder(String packId, Folder target) {
        Folder old = folderOf(packId);
        if (old == target) return;

        rootOrder.remove("P:" + packId);
        if (old != null) {
            old.packs.remove(packId);
        }
        if (target == null) {
            int at = rootOrder.size();
            if (old != null) {
                int folderIdx = rootOrder.indexOf("F:" + old.id);
                if (folderIdx >= 0) at = folderIdx + 1;
            }
            rootOrder.add(Math.min(at, rootOrder.size()), "P:" + packId);
        } else {
            target.packs.add(packId);
        }
    }

    /** まだ記録されていないパックを並び順リストの末尾に追加する */
    public void sync(Collection<String> packIds) {
        Set<String> inFolder = new HashSet<>();
        for (Folder f : folders) inFolder.addAll(f.packs);
        Set<String> tokens = new HashSet<>(rootOrder);
        for (String id : packIds) {
            if (inFolder.contains(id)) continue;
            String token = "P:" + id;
            if (tokens.add(token)) {
                rootOrder.add(token);
            }
        }
    }

    /**
     * list 内の token を dir(-1=上, +1=下) 方向に動かす。
     * visible が false の要素（絞り込みで隠れているもの）は飛び越える。
     */
    public boolean moveToken(List<String> list, String token, int dir, Predicate<String> visible) {
        int i = list.indexOf(token);
        if (i < 0) return false;
        int j = i + dir;
        while (j >= 0 && j < list.size() && !visible.test(list.get(j))) {
            j += dir;
        }
        if (j < 0 || j >= list.size()) return false;
        list.remove(i);
        list.add(j, token);
        return true;
    }
}
